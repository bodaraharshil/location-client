import { combineReducers } from "redux";

import Eventreducer from "./eventreducer";

const Rootreducer = combineReducers({
  Eventreducer,
});

export default Rootreducer;
